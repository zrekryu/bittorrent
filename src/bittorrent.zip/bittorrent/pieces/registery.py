from collections.abc import Buffer
import math
from typing import ClassVar, Final

from .piece from Piece
from .block import Block


class PieceRegistry:
    BLOCK_SIZE: ClassVar[Final[int]] = 2**14

    def __init__(
        self,
        piece_length: int,
        pieces_hash: Buffer,
        total_length: int,
        block_size: int | None = None
    ) -> None:
        self.piece_length = piece_length
        self.pieces_hash = memoryview(pieces_hash)
        self.total_length = total_length
        self.block_size = block_size or BLOCK_SIZE

        self.last_piece_length = self.total_length % self.piece_length or self.piece_length
        self.last_piece_uneven: bool = self.last_piece_length != self.piece_length

        self.num_pieces = math.ceil(self.total_length / self.piece_length)
        self.blocks_per_piece = self.piece_length // self.block_size

        self.blocks_in_last_piece = math.ceil(self.last_piece_length / self.block_size)
        self.last_block_size = self.last_piece_length % self.block_size or self.block_size

        self.pieces: list[Piece] = self._create_pieces()

    def _generate_blocks_per_piece(self) -> list[Block]:
        blocks: list[Block] = []
        for index in range(self.blocks_per_piece):
            block = Block(
                index=index,
                offset=index * self.block_size,
                length=self.block_size,
                is_last=(index == (self.blocks_per_piece - 1))
            )
            blocks.append(block)

        return blocks

    def _generate_blocks_in_last_piece(self) -> list[Block]:
        blocks: list[Block] = []
        for index in range(self.blocks_in_last_piece):
            is_last: bool = (index == (self.blocks_in_last_piece - 1))

            block = Block(
                index=index,
                offset=index * self.block_size,
                length=self.last_block_size if is_last else self.block_size,
                is_last=is_last
            )
            blocks.append(block)

        return blocks

    def _create_pieces(self) -> list[Piece]:
        pieces: list[Piece] = []
        for index in range(self.num_pieces):
            is_last: bool = (index == (self.num_pieces - 1))

            if is_last and self.last_piece_uneven:
                blocks = self._generate_blocks_in_last_piece()
            else:
                blocks = self._generate_blocks_per_piece()

            hash_start = index * 20
            hash_end = hash_start + 20

            piece = Piece(
                index=index,
                length=self.last_piece_length if is_last else self.piece_length,
                piece_hash=self.pieces_hash[hash_start:hash_end],
                blocks=blocks,
                is_last=is_last
            )
            pieces.append(piece)

        return pieces
