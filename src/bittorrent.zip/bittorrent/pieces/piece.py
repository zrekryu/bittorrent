from collections.abc import Buffer, Sequence
from dataclasses import dataclass


class Piece:
    __slots__ = ("index", "length", "piece_hash", "blocks", "is_last")

    def __init__(
        self,
        index: int,
        length: int,
        piece_hash: bytes,
        blocks: Sequence[Block],
        is_last: bool = False
    ) -> None:
        self.index = index
        self.length = length
        self.piece_hash = memoryview(piece_hash)
        self.blocks = list(blocks)
        self.is_last = is_last

    def verify_hash(self, piece_hash: Buffer) -> bool:
        return self.piece_hash == memoryview(piece_hash)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Piece):
            return NotImplemented

        return self.index == other.index

    def __hash__(self) -> int:
        return hash(self.index)

    def __repr__(self) -> str:
        return (
            f"{type(self).__qualname__}("
            f"index={self.index}, "
            f"length={self.length}, "
            f"piece_hash={self.piece_hash!r}, "
            f"blocks={self.blocks}, "
            f"is_last={self.is_last}"
            ")"
        )