class TorrentMetadataInfoFileNode:
    pass
