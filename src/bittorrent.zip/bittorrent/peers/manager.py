class PeerManager:
    uploaded: int
    downloaded: int
    left: int