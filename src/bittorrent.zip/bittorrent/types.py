from __future__ import annotations

from .trackers import (
    HTTPTrackerClient,
    HTTPTrackerAnnounceResponse,
    UDPTrackerClient,
    UDPTrackerAnnounceResponse,
)

from .peers import PeerConnection
from .peers.messages import AbstractPeerMessage


type TrackerClient = HTTPTrackerClient | UDPTrackerClient
type TrackerResponse = HTTPTrackerAnnounceResponse | UDPTrackerAnnounceResponse


type PeerMessageTuple = tuple[PeerConnection, AbstractPeerMessage]
